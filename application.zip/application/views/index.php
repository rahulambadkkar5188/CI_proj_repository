Client Index page

<a href="<?php echo base_url('index.php/admin/admin');?>">Admin Link</a>